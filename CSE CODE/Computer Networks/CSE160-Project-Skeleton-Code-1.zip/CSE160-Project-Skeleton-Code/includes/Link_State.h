#ifndef Link_State_H
#define Link_State_H


typedef nx_struct link {
       nx_uint16_t src;
       nx_uint16_t neigh;
       nx_uint16_t cost;

 } link;


typedef nx_struct routing {


       nx_uint16_t dest;
       nx_uint16_t cost;
       nx_uint16_t nexthop;
} routing;




#endif

