#ifndef Socket_Struct_H
#define Socket_Struct_H


typedef nx_struct socketServer {
       nx_uint16_t port;
       nx_uint16_t dest;
       nx_uint16_t ;

 } socket;



#endif

